# Production Security Best Practices

## 🔐 Güvenlik Prensipleri

### 1. Defense in Depth (Katmanlı Savunma)

Hiçbir tek güvenlik önlemi yeterli değildir. Birden fazla katman kullan:

```
Layer 1: Network (Firewall, Nginx)
Layer 2: Application (Rate limiting, input validation)
Layer 3: Authentication (JWT, session management)
Layer 4: Authorization (User permissions)
Layer 5: Data (Encryption at rest)
Layer 6: Monitoring (Logs, alerts)
```

### 2. Principle of Least Privilege

Her sistem komponenti sadece işini yapmak için gereken minimum yetkiye sahip olmalı:

- ✅ `backenduser` sadece `/opt/backend` dizinine erişebilir
- ✅ Nginx user sadece gerekli portları dinler
- ✅ Firebase Admin SDK sadece backend'de
- ✅ Redis sadece localhost'tan erişilebilir

### 3. Fail Secure

Bir hata olduğunda sistem güvenli tarafta fail olmalı:

- ✅ JWT verify başarısız → 401 Unauthorized
- ✅ Session bulunamadı → 401 Unauthorized
- ✅ Rate limit aşıldı → 429 Too Many Requests
- ✅ Redis bağlantı hatası → Graceful degradation (rate limit atlanabilir ama log'a yazılır)

### 4. Zero Trust

Client'a asla güvenme:

- ❌ Frontend'den gelen deviceId'ye güvenme (spoof edilebilir)
- ❌ Client-side validation'a güvenme (backend'de de validate et)
- ❌ "Gizli" API endpoint'lere güvenme (her endpoint authenticated olmalı)
- ❌ CORS'un güvenlik sağladığını sanma (sadece browser kısıtlaması)

## 🛡️ Common Vulnerabilities & Mitigations

### SQL/NoSQL Injection

**Risk:** Firestore query injection
**Mitigation:**
- ✅ Joi validation ile input sanitization
- ✅ Firestore Admin SDK parameterized queries kullanır
- ✅ User input asla direkt query'ye gitmiyor

### XSS (Cross-Site Scripting)

**Risk:** Flutter web localStorage'dan token çalınması
**Mitigation:**
- ⚠️ localStorage XSS'e açık (httpOnly cookie daha güvenli ama CORS karmaşık)
- ✅ CSP headers (Content-Security-Policy)
- ✅ Short-lived access token (10 dakika)
- ✅ Helmet.js security headers

### CSRF (Cross-Site Request Forgery)

**Risk:** Sahte request'ler
**Mitigation:**
- ✅ JWT token required (automatic CSRF protection)
- ✅ SameSite cookie flags (eğer cookie kullanıyorsan)
- ✅ Origin header check (Nginx + CORS)

### Session Hijacking

**Risk:** Token çalındığında taklit edilme
**Mitigation:**
- ✅ Device fingerprinting (IP + user-agent check)
- ✅ Short-lived JWT (10 dakika)
- ✅ Session revocation (anında logout)
- ✅ Anomaly detection (IP değişimi, location değişimi)

### Brute Force Attack

**Risk:** Password deneme saldırıları
**Mitigation:**
- ✅ Rate limiting (IP-based: 5 req/min)
- ✅ Fail2ban (3 başarısız deneme → ban)
- ✅ Account lockout (opsiyonel: 5 failed attempt → temporary lock)
- ✅ CAPTCHA (opsiyonel: frontend'de eklenebilir)

### DDoS (Distributed Denial of Service)

**Risk:** Sistem kaynakları tükenmesi
**Mitigation:**
- ⚠️ Nginx rate limiting (basic protection)
- ⚠️ Connection limiting (max 10 concurrent per IP)
- ❌ Advanced DDoS için Cloudflare/Cloud Armor gerekli
- ✅ PM2 cluster mode (load distribution)

### Man-in-the-Middle (MITM)

**Risk:** Network traffic dinlenmesi
**Mitigation:**
- ✅ HTTPS/TLS 1.3 (forced)
- ✅ HSTS headers (prevent downgrade)
- ✅ Certificate pinning (opsiyonel: mobile app'de)

### Replay Attack

**Risk:** Eski token'ların tekrar kullanılması
**Mitigation:**
- ✅ JTI (JWT ID) uniqueness (Redis cache)
- ✅ Timestamp validation (5 dakika tolerance)
- ✅ Nonce kullanımı (opsiyonel: critical endpoints)

### Privilege Escalation

**Risk:** Normal user admin yetkisi kazanması
**Mitigation:**
- ✅ Session userId backend'de doğrulanır (client'tan gelene güvenilmez)
- ✅ Firebase Admin SDK ile user claims kontrolü
- ✅ Endpoint-level authorization checks

## 📊 Security Monitoring

### Log Events (CRITICAL)

**Her zaman log'la:**
- ✅ Failed login attempts (email, IP, timestamp)
- ✅ Session revocations (reason, userId)
- ✅ Rate limit violations (IP, endpoint)
- ✅ Token replay detection (jti)
- ✅ Device limit exceeded (userId, deviceCount)
- ✅ Suspicious activity (IP change, location change)
- ✅ Admin actions (user deletion, permission changes)

**Asla log'lama:**
- ❌ Passwords (plaintext veya hashed)
- ❌ JWT tokens (full token)
- ❌ API keys / secrets
- ❌ Sensitive user data (SSN, credit card)

### Alert Triggers

**Hemen alert gönder:**
- 🚨 Birden fazla failed login (same IP, 10+ attempts)
- 🚨 Token replay detected (potential attack)
- 🚨 Unusual traffic spike (10x normal)
- 🚨 Firebase Admin SDK auth failure
- 🚨 Redis connection loss
- 🚨 Disk space < 10%
- 🚨 SSL certificate expiring (< 30 days)

## 🔄 Security Maintenance

### Daily

- [ ] Check error logs (`grep ERROR /opt/backend/logs/combined.log`)
- [ ] Check Fail2ban status (`sudo fail2ban-client status`)
- [ ] Monitor disk usage (`df -h`)

### Weekly

- [ ] Review security event logs (`grep SECURITY_EVENT`)
- [ ] Check for failed login patterns
- [ ] Review rate limit violations
- [ ] PM2 health check

### Monthly

- [ ] Update dependencies (`npm outdated`, `npm audit`)
- [ ] Review and rotate logs
- [ ] Review user session counts
- [ ] Security patch updates (`apt update && apt upgrade`)

### Quarterly

- [ ] Rotate Firebase service account key
- [ ] Review and update security policies
- [ ] Penetration testing (opsiyonel)
- [ ] Security audit
- [ ] Update SSL certificates (otomatik ama kontrol et)

### Yearly

- [ ] Rotate RSA key pair (JWT signing)
- [ ] Full security audit
- [ ] Disaster recovery test
- [ ] Review and update incident response plan

## ⚠️ Incident Response

### Suspected Breach

1. **Immediate Actions:**
   - [ ] PM2 stop (shutdown backend)
   - [ ] Revoke all refresh tokens
   - [ ] Change all passwords (DB, Redis, SSH)
   - [ ] Rotate Firebase service account key
   - [ ] Alert team

2. **Investigation:**
   - [ ] Review logs (last 7 days)
   - [ ] Check for unauthorized access
   - [ ] Identify breach vector
   - [ ] Document timeline

3. **Remediation:**
   - [ ] Patch vulnerability
   - [ ] Deploy fixed version
   - [ ] Notify affected users
   - [ ] File security report

4. **Post-Incident:**
   - [ ] Update security policies
   - [ ] Add new monitoring rules
   - [ ] Team debrief
   - [ ] Document lessons learned

## 🎓 Security Training

**Developer Best Practices:**

1. **Never commit secrets:**
   ```bash
   git secrets --scan  # Pre-commit hook
   ```

2. **Always use parameterized queries:**
   ```javascript
   // ✅ Good
   db.collection('users').doc(userId).get();
   
   // ❌ Bad
   db.collection('users').doc(req.body.userId).get();  // Validate first!
   ```

3. **Validate all inputs:**
   ```javascript
   // ✅ Good
   const { error } = validateInput(req.body);
   if (error) return res.status(400).json({ error });
   
   // ❌ Bad
   const userId = req.body.userId;  // No validation!
   ```

4. **Use secure headers:**
   ```javascript
   // ✅ Already implemented (Helmet.js)
   app.use(helmet());
   ```

5. **Rate limit everything:**
   ```javascript
   // ✅ Good - Different limits for different endpoints
   router.post('/login', loginLimiter, ...);
   router.get('/profile', userLimiter(100, 1), ...);
   ```

---

**REMEMBER:** Güvenlik bir destination değil, journey'dir. Sürekli improvement gereklidir.
