const fs = require('fs');
require('dotenv').config();

const PRIVATE_KEY = fs.readFileSync(process.env.JWT_PRIVATE_KEY_PATH, 'utf8');
const PUBLIC_KEY = fs.readFileSync(process.env.JWT_PUBLIC_KEY_PATH, 'utf8');

module.exports = {
  privateKey: PRIVATE_KEY,
  publicKey: PUBLIC_KEY,
  algorithm: 'RS256',
  accessTokenExpiry: process.env.JWT_ACCESS_EXPIRY || '10m',
  refreshTokenExpiry: process.env.JWT_REFRESH_EXPIRY || '30d',
  issuer: process.env.JWT_ISSUER || 'api.yourdomain.com',
  audience: process.env.JWT_AUDIENCE || 'app.yourdomain.com'
};
