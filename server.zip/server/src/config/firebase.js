const admin = require('firebase-admin');
require('dotenv').config();

const serviceAccount = require(process.env.FIREBASE_SERVICE_ACCOUNT);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: serviceAccount.databaseURL || process.env.FIREBASE_DATABASE_URL
});

const db = admin.firestore();
const auth = admin.auth();
const realtimeDb = admin.database();

module.exports = {
  admin,
  db,
  auth,
  realtimeDb
};
