const { db } = require('../config/firebase');
const constants = require('../config/constants');
const logger = require('../utils/logger');

const sessionValidator = async (req, res, next) => {
  try {
    const sessionId = req.user?.sessionId;
    
    if (!sessionId) {
      return res.status(401).json({ error: 'No session ID in token' });
    }
    
    const sessionDoc = await db.collection('sessions').doc(sessionId).get();
    
    if (!sessionDoc.exists) {
      logger.warn('Session not found', { sessionId, userId: req.user.userId });
      return res.status(401).json({ error: 'Session not found' });
    }
    
    const session = sessionDoc.data();
    
    if (session.revoked) {
      logger.warn('Session revoked', { sessionId, reason: session.revokeReason });
      return res.status(401).json({
        error: 'Session revoked',
        reason: session.revokeReason
      });
    }
    
    const lastSeen = session.lastSeenAt.toDate();
    const daysSinceLastSeen = (Date.now() - lastSeen.getTime()) / (1000 * 60 * 60 * 24);
    
    if (daysSinceLastSeen > constants.SESSION_INACTIVITY_DAYS) {
      await db.collection('sessions').doc(sessionId).update({
        revoked: true,
        revokedAt: new Date(),
        revokeReason: 'inactivity_timeout'
      });
      
      logger.info('Session expired due to inactivity', { sessionId });
      return res.status(401).json({ error: 'Session expired due to inactivity' });
    }
    
    const shouldUpdate = daysSinceLastSeen > 0.1;
    if (shouldUpdate) {
      db.collection('sessions').doc(sessionId).update({
        lastSeenAt: new Date()
      }).catch(err => logger.error('Failed to update lastSeenAt', err));
    }
    
    req.session = session;
    next();
  } catch (error) {
    logger.error('Session validator error:', error);
    return res.status(500).json({ error: 'Session validation failed' });
  }
};

module.exports = sessionValidator;
