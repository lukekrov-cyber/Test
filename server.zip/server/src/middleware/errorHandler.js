const logger = require('../utils/logger');

const errorHandler = (err, req, res, next) => {
  logger.error('Error handler caught:', {
    error: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method,
    ip: req.ip
  });

  if (err.name === 'ValidationError') {
    return res.status(400).json({
      error: 'Validation error',
      details: err.details
    });
  }

  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      error: 'Unauthorized'
    });
  }

  if (err.code === 'auth/user-not-found') {
    return res.status(404).json({
      error: 'User not found'
    });
  }

  if (err.code === 'auth/wrong-password') {
    return res.status(401).json({
      error: 'Invalid credentials'
    });
  }

  res.status(500).json({
    error: 'Internal server error'
  });
};

const notFoundHandler = (req, res) => {
  res.status(404).json({
    error: 'Endpoint not found'
  });
};

module.exports = {
  errorHandler,
  notFoundHandler
};
