const { redisClient } = require('./rateLimiter');
const jwt = require('jsonwebtoken');
const constants = require('../config/constants');
const logger = require('../utils/logger');

const replayProtection = async (req, res, next) => {
  if (!constants.REPLAY_PROTECTION_ENABLED) {
    return next();
  }

  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return next();
    
    const decoded = jwt.decode(token);
    const jti = decoded?.jti;
    const exp = decoded?.exp;
    
    if (!jti) {
      logger.warn('Token missing jti', { ip: req.ip });
      return res.status(401).json({ error: 'Invalid token: missing jti' });
    }
    
    const key = `jti:${jti}`;
    const used = await redisClient.get(key);
    
    if (used) {
      logger.warn('Token replay detected', { jti, ip: req.ip });
      return res.status(401).json({ error: 'Token replay detected' });
    }
    
    const ttl = exp - Math.floor(Date.now() / 1000);
    if (ttl > 0) {
      await redisClient.setEx(key, ttl, '1');
    }
    
    next();
  } catch (error) {
    logger.error('Replay protection error:', error);
    next();
  }
};

const timestampCheck = (req, res, next) => {
  const timestamp = req.headers['x-request-timestamp'];
  
  if (!timestamp) {
    return next();
  }
  
  const now = Date.now();
  const diff = Math.abs(now - parseInt(timestamp));
  
  if (diff > constants.TIMESTAMP_TOLERANCE_MS) {
    logger.warn('Request timestamp expired', { diff, ip: req.ip });
    return res.status(401).json({ error: 'Request timestamp expired' });
  }
  
  next();
};

module.exports = {
  replayProtection,
  timestampCheck
};
