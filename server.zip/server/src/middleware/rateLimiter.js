const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const redis = require('redis');
const constants = require('../config/constants');

const redisClient = redis.createClient({
  socket: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379
  },
  password: process.env.REDIS_PASSWORD || undefined
});

redisClient.connect().catch(console.error);

const ipLimiter = rateLimit({
  store: new RedisStore({
    client: redisClient,
    prefix: 'rl:ip:'
  }),
  windowMs: constants.RATE_LIMIT_WINDOW_MS,
  max: constants.RATE_LIMIT_MAX_REQUESTS,
  message: 'Too many requests from this IP, please try again later',
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.path === '/health'
});

const loginLimiter = rateLimit({
  store: new RedisStore({
    client: redisClient,
    prefix: 'rl:login:'
  }),
  windowMs: constants.LOGIN_RATE_LIMIT_WINDOW_MS,
  max: constants.LOGIN_RATE_LIMIT_MAX,
  message: 'Too many login attempts, please try again later',
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  keyGenerator: (req) => {
    return req.ip + ':' + (req.body.email || 'unknown');
  }
});

const userLimiter = (maxRequests = 50, windowMinutes = 1) => {
  return async (req, res, next) => {
    const userId = req.user?.userId;
    if (!userId) return next();
    
    const key = `rl:user:${userId}`;
    const windowSeconds = windowMinutes * 60;
    
    try {
      const current = await redisClient.incr(key);
      
      if (current === 1) {
        await redisClient.expire(key, windowSeconds);
      }
      
      if (current > maxRequests) {
        return res.status(429).json({
          error: 'Too many requests from this user'
        });
      }
      
      next();
    } catch (error) {
      console.error('User rate limiter error:', error);
      next();
    }
  };
};

module.exports = {
  ipLimiter,
  loginLimiter,
  userLimiter,
  redisClient
};
