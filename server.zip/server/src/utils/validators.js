const Joi = require('joi');

const validateRegistration = (data) => {
  const schema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    name: Joi.string().min(2).max(50).required(),
    phone: Joi.string().allow('', null).optional(),
    country: Joi.string().allow('', null).optional(),
    deviceInfo: Joi.object({
      deviceId: Joi.string().optional(),
      userAgent: Joi.string().optional(),
      screenResolution: Joi.string().optional(),
      timezone: Joi.string().optional(),
      language: Joi.string().optional(),
      platform: Joi.string().optional()
    }).optional()
  });

  return schema.validate(data);
};

const validateLogin = (data) => {
  const schema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
    deviceInfo: Joi.object({
      deviceId: Joi.string().optional(),
      userAgent: Joi.string().optional(),
      screenResolution: Joi.string().optional(),
      timezone: Joi.string().optional(),
      language: Joi.string().optional(),
      platform: Joi.string().optional()
    }).optional()
  });

  return schema.validate(data);
};

module.exports = {
  validateRegistration,
  validateLogin
};
