const crypto = require('crypto');
const bcrypt = require('bcrypt');

const hashPassword = async (password) => {
  const saltRounds = 10;
  return await bcrypt.hash(password, saltRounds);
};

const comparePassword = async (password, hash) => {
  return await bcrypt.compare(password, hash);
};

const generateRandomToken = (length = 32) => {
  return crypto.randomBytes(length).toString('hex');
};

const sha256Hash = (input) => {
  return crypto.createHash('sha256').update(input).digest('hex');
};

module.exports = {
  hashPassword,
  comparePassword,
  generateRandomToken,
  sha256Hash
};
