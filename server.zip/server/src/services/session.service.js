const { v4: uuidv4 } = require('uuid');
const { db } = require('../config/firebase');
const constants = require('../config/constants');

const createSession = async (userId, deviceId, deviceInfo, ip) => {
  const sessionId = uuidv4();
  
  const deviceName = `${deviceInfo.platform || 'Unknown'} - ${deviceInfo.userAgent?.split(' ')[0] || 'Unknown Browser'}`;
  
  await db.collection('sessions').doc(sessionId).set({
    sessionId,
    userId,
    deviceId,
    deviceName,
    ipAddress: ip,
    createdAt: new Date(),
    lastSeenAt: new Date(),
    revoked: false,
    revokedAt: null,
    revokeReason: null
  });
  
  return sessionId;
};

const getActiveSessions = async (userId, currentSessionId) => {
  const snapshot = await db.collection('sessions')
    .where('userId', '==', userId)
    .where('revoked', '==', false)
    .get();
  
  const sessions = [];
  
  snapshot.forEach(doc => {
    const session = doc.data();
    sessions.push({
      sessionId: session.sessionId,
      deviceName: session.deviceName,
      ipAddress: session.ipAddress,
      lastSeenAt: session.lastSeenAt.toDate().toISOString(),
      isCurrent: session.sessionId === currentSessionId
    });
  });
  
  sessions.sort((a, b) => new Date(b.lastSeenAt) - new Date(a.lastSeenAt));
  
  return sessions;
};

const revokeSession = async (sessionId, userId) => {
  const sessionDoc = await db.collection('sessions').doc(sessionId).get();
  
  if (!sessionDoc.exists) {
    throw new Error('Session not found');
  }
  
  const session = sessionDoc.data();
  
  if (session.userId !== userId) {
    throw new Error('Unauthorized');
  }
  
  await db.collection('sessions').doc(sessionId).update({
    revoked: true,
    revokedAt: new Date(),
    revokeReason: 'user_logout'
  });
  
  const refreshTokens = await db.collection('refreshTokens')
    .where('sessionId', '==', sessionId)
    .where('revoked', '==', false)
    .get();
  
  const batch = db.batch();
  refreshTokens.forEach(doc => {
    batch.update(doc.ref, {
      revoked: true,
      revokedAt: new Date()
    });
  });
  await batch.commit();
};

const revokeOldestSession = async (userId) => {
  const snapshot = await db.collection('sessions')
    .where('userId', '==', userId)
    .where('revoked', '==', false)
    .orderBy('lastSeenAt', 'asc')
    .limit(1)
    .get();
  
  if (!snapshot.empty) {
    const oldestSession = snapshot.docs[0];
    await revokeSession(oldestSession.id, userId);
  }
};

const getActiveSessionCount = async (userId) => {
  const snapshot = await db.collection('sessions')
    .where('userId', '==', userId)
    .where('revoked', '==', false)
    .get();
  
  return snapshot.size;
};

module.exports = {
  createSession,
  getActiveSessions,
  revokeSession,
  revokeOldestSession,
  getActiveSessionCount
};
