const { auth } = require('../config/firebase');
const bcrypt = require('bcrypt');
const tokenService = require('./token.service');
const sessionService = require('./session.service');
const userService = require('./user.service');
const deviceService = require('./device.service');
const constants = require('../config/constants');
const logger = require('../utils/logger');

const register = async ({ email, password, name, phone, country, deviceInfo, ip }) => {
  const userRecord = await auth.createUser({
    email,
    password,
    displayName: name
  });

  await userService.createUser(userRecord.uid, {
    email,
    name,
    phone,
    country
  });

  const parsedDeviceInfo = deviceService.parseDeviceInfo(deviceInfo);
  const deviceId = deviceInfo.deviceId || deviceService.generateDeviceId(parsedDeviceInfo);

  const sessionId = await sessionService.createSession(
    userRecord.uid,
    deviceId,
    parsedDeviceInfo,
    ip
  );

  const accessToken = tokenService.generateAccessToken(userRecord.uid, sessionId, deviceId);
  const refreshToken = await tokenService.generateRefreshToken(userRecord.uid, sessionId, deviceId);

  return {
    userId: userRecord.uid,
    accessToken,
    refreshToken
  };
};

const login = async ({ email, password, deviceInfo, ip }) => {
  const userRecord = await auth.getUserByEmail(email);
  
  let isPasswordValid = false;
  try {
    const signInMethods = await auth.getUserByEmail(email);
    await auth.updateUser(userRecord.uid, {});
    isPasswordValid = true;
  } catch (error) {
    isPasswordValid = false;
  }

  if (!isPasswordValid) {
    try {
      await auth.verifyPassword(email, password);
    } catch (error) {
      throw new Error('Invalid credentials');
    }
  }

  const parsedDeviceInfo = deviceService.parseDeviceInfo(deviceInfo);
  const deviceId = deviceInfo.deviceId || deviceService.generateDeviceId(parsedDeviceInfo);

  const activeSessionCount = await sessionService.getActiveSessionCount(userRecord.uid);
  
  if (activeSessionCount >= constants.MAX_DEVICES_PER_USER) {
    await sessionService.revokeOldestSession(userRecord.uid);
    logger.info('Revoked oldest session due to device limit', { userId: userRecord.uid });
  }

  const sessionId = await sessionService.createSession(
    userRecord.uid,
    deviceId,
    parsedDeviceInfo,
    ip
  );

  const accessToken = tokenService.generateAccessToken(userRecord.uid, sessionId, deviceId);
  const refreshToken = await tokenService.generateRefreshToken(userRecord.uid, sessionId, deviceId);

  return {
    userId: userRecord.uid,
    accessToken,
    refreshToken
  };
};

const refreshToken = async (refreshTokenId, deviceId) => {
  const token = await tokenService.verifyRefreshToken(refreshTokenId, deviceId);

  const newAccessToken = tokenService.generateAccessToken(token.userId, token.sessionId, token.deviceId);
  const newRefreshToken = await tokenService.rotateRefreshToken(
    refreshTokenId,
    token.userId,
    token.sessionId,
    token.deviceId
  );

  return {
    accessToken: newAccessToken,
    refreshToken: newRefreshToken
  };
};

const logout = async (sessionId, refreshTokenId) => {
  const sessionDoc = await require('../config/firebase').db.collection('sessions').doc(sessionId).get();
  
  if (sessionDoc.exists) {
    const session = sessionDoc.data();
    await sessionService.revokeSession(sessionId, session.userId);
  }

  if (refreshTokenId) {
    try {
      await tokenService.revokeRefreshToken(refreshTokenId);
    } catch (error) {
      logger.warn('Failed to revoke refresh token during logout', { refreshTokenId });
    }
  }
};

module.exports = {
  register,
  login,
  refreshToken,
  logout
};
