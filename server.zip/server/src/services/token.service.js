const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const jwtConfig = require('../config/jwt');
const { db } = require('../config/firebase');

const generateAccessToken = (userId, sessionId, deviceId) => {
  const payload = {
    userId,
    sessionId,
    deviceId,
    jti: uuidv4(),
    type: 'access'
  };
  
  return jwt.sign(payload, jwtConfig.privateKey, {
    algorithm: jwtConfig.algorithm,
    expiresIn: jwtConfig.accessTokenExpiry,
    issuer: jwtConfig.issuer,
    audience: jwtConfig.audience
  });
};

const generateRefreshToken = async (userId, sessionId, deviceId) => {
  const tokenId = uuidv4();
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  
  await db.collection('refreshTokens').doc(tokenId).set({
    tokenId,
    userId,
    sessionId,
    deviceId,
    issuedAt: new Date(),
    expiresAt: expiresAt,
    revoked: false,
    revokedAt: null,
    rotatedTo: null
  });
  
  return tokenId;
};

const verifyRefreshToken = async (tokenId, deviceId) => {
  const tokenDoc = await db.collection('refreshTokens').doc(tokenId).get();
  
  if (!tokenDoc.exists) {
    throw new Error('Invalid refresh token');
  }
  
  const token = tokenDoc.data();
  
  if (token.revoked) {
    throw new Error('Refresh token revoked');
  }
  
  if (token.expiresAt.toDate() < new Date()) {
    throw new Error('Refresh token expired');
  }
  
  if (token.deviceId !== deviceId) {
    throw new Error('Device mismatch');
  }
  
  return token;
};

const rotateRefreshToken = async (oldTokenId, userId, sessionId, deviceId) => {
  const newTokenId = await generateRefreshToken(userId, sessionId, deviceId);
  
  await db.collection('refreshTokens').doc(oldTokenId).update({
    revoked: true,
    revokedAt: new Date(),
    rotatedTo: newTokenId
  });
  
  return newTokenId;
};

const revokeRefreshToken = async (tokenId) => {
  await db.collection('refreshTokens').doc(tokenId).update({
    revoked: true,
    revokedAt: new Date()
  });
};

module.exports = {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
  rotateRefreshToken,
  revokeRefreshToken
};
