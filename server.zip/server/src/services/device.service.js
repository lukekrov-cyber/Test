const crypto = require('crypto');

const generateDeviceId = (deviceInfo) => {
  const fingerprint = [
    deviceInfo.userAgent || '',
    deviceInfo.screenResolution || '',
    deviceInfo.timezone || '',
    deviceInfo.language || '',
    deviceInfo.platform || ''
  ].join('|');
  
  return crypto.createHash('sha256').update(fingerprint).digest('hex');
};

const parseDeviceInfo = (deviceInfo) => {
  return {
    userAgent: deviceInfo.userAgent || 'Unknown',
    screenResolution: deviceInfo.screenResolution || 'Unknown',
    timezone: deviceInfo.timezone || 'Unknown',
    language: deviceInfo.language || 'Unknown',
    platform: deviceInfo.platform || 'Unknown'
  };
};

module.exports = {
  generateDeviceId,
  parseDeviceInfo
};
