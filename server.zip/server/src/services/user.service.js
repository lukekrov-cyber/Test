const { auth, db } = require('../config/firebase');

const getUserProfile = async (userId) => {
  const userDoc = await db.collection('users').doc(userId).get();
  
  if (!userDoc.exists) {
    return null;
  }
  
  const userData = userDoc.data();
  
  return {
    userId,
    email: userData.email,
    name: userData.name,
    phone: userData.phone,
    country: userData.country
  };
};

const updateUserProfile = async (userId, updates) => {
  const allowedUpdates = {};
  
  if (updates.name !== undefined) allowedUpdates.name = updates.name;
  if (updates.phone !== undefined) allowedUpdates.phone = updates.phone;
  if (updates.country !== undefined) allowedUpdates.country = updates.country;
  
  await db.collection('users').doc(userId).update(allowedUpdates);
  
  if (updates.name) {
    await auth.updateUser(userId, {
      displayName: updates.name
    });
  }
  
  return getUserProfile(userId);
};

const createUser = async (userId, userData) => {
  await db.collection('users').doc(userId).set({
    userId,
    email: userData.email,
    name: userData.name,
    phone: userData.phone || null,
    country: userData.country || null,
    createdAt: new Date(),
    updatedAt: new Date()
  });
};

module.exports = {
  getUserProfile,
  updateUserProfile,
  createUser
};
