const authService = require('../services/auth.service');
const logger = require('../utils/logger');
const { validateRegistration, validateLogin } = require('../utils/validators');

const register = async (req, res, next) => {
  try {
    const { error } = validateRegistration(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { email, password, name, phone, country, deviceInfo } = req.body;
    const ip = req.ip || req.connection.remoteAddress;

    const result = await authService.register({
      email,
      password,
      name,
      phone,
      country,
      deviceInfo,
      ip
    });

    logger.info('User registered', { email, userId: result.userId });

    res.status(201).json({
      accessToken: result.accessToken,
      refreshToken: result.refreshToken,
      expiresIn: 600
    });
  } catch (error) {
    logger.error('Register error:', error);
    
    if (error.code === 'auth/email-already-exists') {
      return res.status(400).json({ 
        error: 'This email is already registered. Please use a different email or try logging in.' 
      });
    }
    
    next(error);
  }
};

const login = async (req, res, next) => {
  try {
    const { error } = validateLogin(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { email, password, deviceInfo } = req.body;
    const ip = req.ip || req.connection.remoteAddress;

    const result = await authService.login({
      email,
      password,
      deviceInfo,
      ip
    });

    logger.info('User logged in', { email, userId: result.userId });

    res.json({
      accessToken: result.accessToken,
      refreshToken: result.refreshToken,
      expiresIn: 600
    });
  } catch (error) {
    logger.error('Login error:', error);
    
    if (error.message === 'Invalid credentials') {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    if (error.message === 'Max device limit reached') {
      return res.status(403).json({ 
        error: 'Maximum device limit reached. Please logout from another device.' 
      });
    }
    
    next(error);
  }
};

const refresh = async (req, res, next) => {
  try {
    const { refreshToken, deviceId } = req.body;

    if (!refreshToken || !deviceId) {
      return res.status(400).json({ error: 'Missing refreshToken or deviceId' });
    }

    const result = await authService.refreshToken(refreshToken, deviceId);

    res.json({
      accessToken: result.accessToken,
      refreshToken: result.refreshToken,
      expiresIn: 600
    });
  } catch (error) {
    logger.error('Refresh token error:', error);
    
    if (error.message === 'Invalid refresh token') {
      return res.status(401).json({ error: 'Invalid or expired refresh token' });
    }
    
    next(error);
  }
};

const logout = async (req, res, next) => {
  try {
    const { sessionId, userId } = req.user;
    const { refreshToken } = req.body;

    await authService.logout(sessionId, refreshToken);

    logger.info('User logged out', { userId, sessionId });

    res.json({ success: true });
  } catch (error) {
    logger.error('Logout error:', error);
    next(error);
  }
};

module.exports = {
  register,
  login,
  refresh,
  logout
};
