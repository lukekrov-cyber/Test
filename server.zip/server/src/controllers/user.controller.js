const userService = require('../services/user.service');
const logger = require('../utils/logger');

const getProfile = async (req, res, next) => {
  try {
    const { userId } = req.user;

    const user = await userService.getUserProfile(userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    logger.error('Get profile error:', error);
    next(error);
  }
};

const updateProfile = async (req, res, next) => {
  try {
    const { userId } = req.user;
    const { name, phone, country } = req.body;

    const updatedUser = await userService.updateUserProfile(userId, {
      name,
      phone,
      country
    });

    logger.info('User profile updated', { userId });

    res.json({ user: updatedUser });
  } catch (error) {
    logger.error('Update profile error:', error);
    next(error);
  }
};

module.exports = {
  getProfile,
  updateProfile
};
