const sessionService = require('../services/session.service');
const logger = require('../utils/logger');

const getActiveSessions = async (req, res, next) => {
  try {
    const { userId, sessionId } = req.user;

    const sessions = await sessionService.getActiveSessions(userId, sessionId);

    res.json({ sessions });
  } catch (error) {
    logger.error('Get active sessions error:', error);
    next(error);
  }
};

const revokeSession = async (req, res, next) => {
  try {
    const { userId } = req.user;
    const { sessionId } = req.params;

    await sessionService.revokeSession(sessionId, userId);

    logger.info('Session revoked by user', { userId, revokedSessionId: sessionId });

    res.json({ success: true });
  } catch (error) {
    logger.error('Revoke session error:', error);
    
    if (error.message === 'Session not found') {
      return res.status(404).json({ error: 'Session not found' });
    }
    
    if (error.message === 'Unauthorized') {
      return res.status(403).json({ error: 'You can only revoke your own sessions' });
    }
    
    next(error);
  }
};

module.exports = {
  getActiveSessions,
  revokeSession
};
