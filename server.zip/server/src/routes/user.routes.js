const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const authMiddleware = require('../middleware/auth');
const sessionValidator = require('../middleware/sessionValidator');
const { userLimiter } = require('../middleware/rateLimiter');

router.get('/profile', authMiddleware, sessionValidator, userLimiter(100, 1), userController.getProfile);
router.put('/profile', authMiddleware, sessionValidator, userLimiter(10, 1), userController.updateProfile);

module.exports = router;
