const express = require('express');
const router = express.Router();
const sessionController = require('../controllers/session.controller');
const authMiddleware = require('../middleware/auth');
const sessionValidator = require('../middleware/sessionValidator');

router.get('/active', authMiddleware, sessionValidator, sessionController.getActiveSessions);
router.delete('/:sessionId', authMiddleware, sessionValidator, sessionController.revokeSession);

module.exports = router;
