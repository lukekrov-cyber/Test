const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { loginLimiter } = require('../middleware/rateLimiter');
const authMiddleware = require('../middleware/auth');
const sessionValidator = require('../middleware/sessionValidator');

router.post('/register', loginLimiter, authController.register);
router.post('/login', loginLimiter, authController.login);
router.post('/refresh', authController.refresh);
router.post('/logout', authMiddleware, sessionValidator, authController.logout);

module.exports = router;
