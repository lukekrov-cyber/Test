# PRODUCTION DEPLOYMENT CHECKLIST

## Pre-Deployment

- [ ] GCP VM oluşturuldu (Ubuntu 22.04 LTS, minimum 2 vCPU, 4GB RAM)
- [ ] SSH key pair oluşturuldu ve server'a eklendi
- [ ] Domain DNS kaydı yapıldı (api.yourdomain.com → VM IP)
- [ ] Firebase projesi oluşturuldu
- [ ] Firebase service account key indirildi
- [ ] Redis kurulumu planlandı

## System Setup

- [ ] Sistem güncellemesi yapıldı (`apt update && apt upgrade`)
- [ ] Dedicated user oluşturuldu (`backenduser`)
- [ ] Node.js 20+ kuruldu
- [ ] Redis kuruldu ve çalışıyor
- [ ] Nginx kuruldu
- [ ] PM2 global olarak kuruldu
- [ ] Certbot (Let's Encrypt) kuruldu

## Security Hardening

- [ ] SSH password authentication kapatıldı
- [ ] Root login kapatıldı
- [ ] UFW firewall yapılandırıldı (22, 80, 443)
- [ ] Fail2ban kuruldu ve yapılandırıldı
- [ ] Unattended-upgrades etkinleştirildi
- [ ] Redis password korunması yapıldı

## Backend Deployment

- [ ] `/opt/backend` klasörü oluşturuldu
- [ ] Backend kod deploy edildi (git clone veya scp)
- [ ] `npm install --production` çalıştırıldı
- [ ] `.env` dosyası oluşturuldu ve yapılandırıldı
- [ ] `.env` dosya izinleri 600 yapıldı
- [ ] RSA key pair oluşturuldu (`npm run generate-keys`)
- [ ] RSA key izinleri 600 yapıldı
- [ ] `serviceAccount.json` güvenli şekilde transfer edildi
- [ ] `serviceAccount.json` izinleri 600 yapıldı
- [ ] Tüm dosyalar `backenduser:backenduser` owner yapıldı

## Firebase Configuration

- [ ] Firestore security rules client access = false yapıldı
- [ ] Realtime Database rules client access = false yapıldı
- [ ] Firebase Admin SDK test edildi
- [ ] Database collections oluşturuldu (users, sessions, refreshTokens)

## Nginx & SSL

- [ ] Nginx config kopyalandı (`docs/nginx.conf`)
- [ ] `server_name` değerleri güncellendi
- [ ] Config test edildi (`nginx -t`)
- [ ] SSL sertifikası alındı (`certbot --nginx`)
- [ ] HTTPS çalışıyor doğrulandı
- [ ] HTTP → HTTPS redirect çalışıyor
- [ ] SSL auto-renewal test edildi (`certbot renew --dry-run`)

## Application Start

- [ ] PM2 ile backend başlatıldı
- [ ] PM2 logs kontrol edildi (hata yok)
- [ ] PM2 startup script oluşturuldu
- [ ] Health check endpoint test edildi (`/health`)
- [ ] PM2 monitoring çalışıyor

## Testing

- [ ] Register endpoint test edildi
- [ ] Login endpoint test edildi
- [ ] Token refresh test edildi
- [ ] Session management test edildi
- [ ] Device limit (5 cihaz) test edildi
- [ ] Rate limiting test edildi
- [ ] Logout çalışıyor
- [ ] Multi-device test edildi
- [ ] Session revocation test edildi
- [ ] Replay protection test edildi

## Monitoring & Logging

- [ ] Application logs yazılıyor (`logs/combined.log`)
- [ ] Error logs yazılıyor (`logs/error.log`)
- [ ] Nginx access log kontrol edildi
- [ ] Nginx error log kontrol edildi
- [ ] PM2 monit çalışıyor
- [ ] Log rotation yapılandırıldı (opsiyonel)

## Security Audit

- [ ] Port taraması yapıldı (sadece 22, 80, 443 açık)
- [ ] Port 3000 external erişime kapalı doğrulandı
- [ ] Firebase client SDK web bundle'da yok doğrulandı
- [ ] .env ve serviceAccount.json web root dışında
- [ ] Tüm secret dosyalar 600 permission
- [ ] Git'te hassas dosyalar yok (.gitignore kontrol)
- [ ] CORS yapılandırması doğru domain
- [ ] Rate limiting çalışıyor
- [ ] JWT expiry doğru (10 dakika)
- [ ] Refresh token rotation çalışıyor

## Documentation

- [ ] Production URL'leri dokümante edildi
- [ ] API endpoint listesi güncel
- [ ] Deployment notları yazıldı
- [ ] Backup & recovery planı oluşturuldu
- [ ] Incident response planı oluşturuldu
- [ ] Takım access bilgileri güvenli şekilde saklandı

## Post-Deployment

- [ ] Frontend CORS_ORIGIN güncellendi
- [ ] Frontend API endpoint güncellendi
- [ ] End-to-end test yapıldı (frontend + backend)
- [ ] Load testing yapıldı (opsiyonel)
- [ ] Monitoring dashboard kuruldu (opsiyonel: Grafana/Prometheus)
- [ ] Alert sistemi kuruldu (opsiyonel)
- [ ] Backup cron job oluşturuldu
- [ ] SSL renewal reminder ayarlandı (90 günde bir)

## Emergency Contacts

- [ ] SSH backup key güvenli yerde saklandı
- [ ] Root şifresi güvenli yerde saklandı
- [ ] Firebase project owner access bilgisi
- [ ] GCP project access bilgisi
- [ ] Domain registrar access bilgisi

---

**DEPLOYMENT TARİHİ:** __________
**DEPLOY EDEN:** __________
**SON TEST TARİHİ:** __________
**SON SSL YENİLEME:** __________
