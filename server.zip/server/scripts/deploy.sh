#!/bin/bash

# Production Deployment Script
# Ubuntu 22.04 LTS on GCP Compute Engine

set -e

echo "🚀 Starting backend deployment..."

# 1. System update
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# 2. Install dependencies
echo "📥 Installing dependencies..."
sudo apt install -y ufw fail2ban redis-server nginx certbot python3-certbot-nginx

# 3. Create dedicated user
echo "👤 Creating backend user..."
if ! id -u backenduser > /dev/null 2>&1; then
    sudo useradd -r -m -s /bin/bash backenduser
fi

# 4. SSH hardening
echo "🔐 Hardening SSH..."
sudo sed -i 's/^#*PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
sudo sed -i 's/^#*PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo systemctl restart sshd

# 5. Firewall setup
echo "🛡️ Configuring firewall..."
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
echo "y" | sudo ufw enable

# 6. Fail2ban
echo "🚫 Configuring Fail2ban..."
sudo systemctl enable fail2ban
sudo systemctl start fail2ban

# 7. Node.js installation
echo "📦 Installing Node.js 20..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# 8. PM2 installation
echo "⚙️ Installing PM2..."
sudo npm install -g pm2

# 9. Backend directory
echo "📁 Setting up backend directory..."
sudo mkdir -p /opt/backend
sudo chown backenduser:backenduser /opt/backend

# 10. Clone or copy backend code
echo "📋 Deploy your backend code to /opt/backend"
echo "   Example: git clone <repo> /opt/backend"

# 11. Install npm packages
echo "📦 Installing npm packages..."
cd /opt/backend
sudo -u backenduser npm install --production

# 12. Generate RSA keys
echo "🔑 Generating RSA keys..."
sudo -u backenduser npm run generate-keys

# 13. Set permissions
echo "🔒 Setting file permissions..."
if [ -f /opt/backend/.env ]; then
    chmod 600 /opt/backend/.env
fi
if [ -f /opt/backend/serviceAccount.json ]; then
    chmod 600 /opt/backend/serviceAccount.json
fi

# 14. Start with PM2
echo "▶️ Starting backend with PM2..."
sudo -u backenduser pm2 start ecosystem.config.js
sudo -u backenduser pm2 save
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u backenduser --hp /home/backenduser

# 15. Nginx configuration
echo "🌐 Configuring Nginx..."
echo "   Copy docs/nginx.conf to /etc/nginx/sites-available/backend-api"
echo "   Then run: sudo ln -s /etc/nginx/sites-available/backend-api /etc/nginx/sites-enabled/"

# 16. SSL certificate
echo "🔐 Get SSL certificate:"
echo "   sudo certbot --nginx -d api.yourdomain.com"

echo "✅ Deployment complete!"
echo ""
echo "⚠️ Don't forget to:"
echo "   1. Add .env file with your configuration"
echo "   2. Add serviceAccount.json from Firebase"
echo "   3. Configure Nginx (docs/nginx.conf)"
echo "   4. Get SSL certificate with certbot"
echo "   5. Restart Nginx: sudo systemctl restart nginx"
