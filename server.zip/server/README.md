# Backend API - Production Ready

Production-level backend API with Firebase Admin SDK, JWT authentication, session management, and device tracking.

## 🏗️ Mimari

```
Client (Flutter Web) → Nginx (443) → Node.js (3000) → Firebase Admin SDK → Firestore
```

## 🔐 Güvenlik Katmanları (Production-Ready)

- ✅ **Network Isolation**: Node.js sadece localhost:3000 (Nginx reverse proxy üzerinden erişim)
- ✅ **HTTPS/TLS 1.3**: Nginx terminasyon
- ✅ **JWT (RS256)**: Short-lived access token (10 dakika)
- ✅ **Refresh Token**: Server-side, revoke edilebilir, 30 gün TTL
- ✅ **Token Rotation**: Her refresh işleminde yeni token (reuse detection)
- ✅ **Session Management**: Device-based tracking, instant revocation
- ✅ **Device Limit**: Max 5 aktif cihaz (Instagram/Telegram mantığı)
- ✅ **Rate Limiting**: Multi-layer (IP + user + device + endpoint)
- ✅ **Replay Attack Protection**: JTI (unique token ID) + timestamp validation
- ✅ **Redis Caching**: Session lookup & rate limit storage
- ✅ **Security Headers**: Helmet.js (CSP, HSTS, X-Frame-Options)
- ✅ **Input Validation**: Joi schemas (all endpoints)
- ✅ **Secrets Isolation**: .env & serviceAccount.json web root DIŞINDA

## 📦 Kurulum (Production)

### ⚠️ ÖNEMLİ GÜVENLİK NOTLARI

1. **Backend konumu**: `/opt/backend` (web root DIŞINDA)
2. **Dosya izinleri**: `.env` ve `serviceAccount.json` → **600**
3. **Sistem kullanıcısı**: Dedicated `backenduser` (root değil)
4. **Network**: Sadece `localhost:3000` dinle (public access yok)
5. **Secrets**: Hiçbir zaman Git'e commit etme

### 1. Bağımlılıkları Yükle

```bash
# Production sunucuda (GCP VM)
cd /opt/backend
sudo -u backenduser npm install --production
```

### 2. Environment Dosyası (CRITICAL)

`.env` dosyası oluştur (`.env.example` referans):

```bash
cp .env.example .env (Production)

**Otomatik (npm script):**
```bash
cd /opt/backend
sudo -u backenduser npm run generate-keys
```

**Manuel (OpenSSL):**
```bash
mkdir -p /opt/backend/keys

# 4096-bit RSA private key
openssl genrsa -out /opt/backend/keys/private.key 4096

# Public key extraction
openssl rsa -in /opt/backend/keys/private.key -pubout -out /opt/backend/keys/public.key

# CRITICAL: Set permissions
chmod 600 /opt/backend/keys/private.key
chmod 600 /opt/backend/keys/public.key
chown backenduser:backenduser /opt/backend/keys/*
```

**Doğrulama:**
```bash
ls -la /opt/backend/keys/
# Expected output: -rw------- 1 backenduser backenduser (size) privateUNLU):**
```bash
chmod 600 /opt/backend/.env
chown backenduser:backenduser /opt/backend/.env
``` (CRITICAL)

**Firebase Console'dan key indir:**
1. [Firebase Console](https://console.firebase.google.com) → Project Settings → Service Accounts
2. "Generate New Private Key" düğmesine tıkla
3. İndirilen JSON dosyasını **güvenli şekilde** transfer et

**Production sunucuya yerleştir:**
```bash
# SCP ile transfer (local → server)
scp serviceAccount.json user@your-server:/tmp/

# Sunucuda güvenli konuma taşı
sudo mv /tmp/serviceAccount.json /opt/backend/
sudo chown backenduser:backenduser /opt/backend/serviceAccount.json
sudo chmod 600 /opt/backend/serviceAccount.json

# Orijinal dosyayı sil (local)
rm serviceAccount.json  # Local makineden sil!
```

**Doğrulama:**
```bash
ls -la /opt/backend/serviceAcco (ZORUNLU)

Firebase Console → Firestore Database → Rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // DEFAULT DENY ALL - Client access tamamen kapalı
    match /{document=**} {
      allow read, write: if false;
    }
    
    // Sadece Firebase Admin SDK erişebilir
    // Node.js backend serviceAccount.json ile authenticate olur
  }
}
```

**Firestore Realtime Database (eğer kullanıyorsanız):**
```json
{
  "rules": {
    ".read": false,
    ".write": false
  }
}
```

**Firebase Storage (eğer kullanıyorsanız):**
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if false;
    }
  }
}
```

**⚠️ CRITICAL:**
- Flutter web app Firebase SDK kullanmayacak
- Client hiçbir zaman doğrudan database'e erişemez
- Tüm işlemler backend API üzerinden
- Bu kurala uymazsan tüm sistem güvenliksiz olur
```

### 4. Firebase Service Account

Firebase Console'dan service account key indir:
1. Firebase Console → Project Settings → Service Accounts
2. "Generate New Private Key" düğmesine tıkla
3. İndirilen JSON dosyasını `serviceAccount.json` olarak kaydet
4. `chmod 600 serviceAccount.json` (Linux/Mac)

### 5. Redis Kurulumu

**Ubuntu/Debian:**
```bash
sudo apt install redis-server
sudo systemctl start redis
sudo systemctl enable redis
```

**Windows:**
```bash
# WSL kullanarak veya Redis Windows port
# https://github.com/microsoftarchive/redis/releases
```

### 6. Firestore Security Rules

Firebase Console → Firestore → Rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

**ÖNEMLİ:** Client access tamamen kapalı olmalı!

## 🚀 Çalıştırma (Production)

### Development (Local Test)

```bash
# .env dosyasında NODE_ENV=development olmalı
npm run dev
```

### Production Deployment (PM2 - Recommended)

**PM2 Kurulumu:**
```bash
sudo npm install -g pm2
```

**Backend başlat:**
```bash
cd /opt/backend
sudo -u backenduser pm2 start ecosystem.config.js

# PM2 logları kontrol et
pm2 logs backend-api

# Status kontrol
pm2 status

# Restart (kod değişikliğinden sonra)
pm2 restart backend-api

# Stop
pm2 stop backend-api
```

**Sistem başlangıcında otomatik başlat:**
```bash
sudo -u backenduser pm2 save
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u backenduser --hp /home/backenduser

# Yukarıdaki komutun output'unda bir komut verecek, onu çalıştır
```

**PM2 Monitoring:**
```bash
pm2 monit  # Real-time monitoring
pm2 logs --lines 100  # Son 100 satır log
pm2 flush  # Log dosyalarını temizle
```

### Nginx Reverse Proxy Setup

**1. Nginx config kopyala:**
```bash
sudo cp /opt/backend/docs/nginx.conf /etc/nginx/sites-available/backend-api
sudo ln -s /etc/nginx/sites-available/backend-api /etc/nginx/sites-enabled/
```

**2. Config düzenle:**
```bash
sudo nano /etc/nginx/sites-available/backend-api
# server_name değerlerini güncelle: api.yourdomain.com
```

**3. Nginx test & reload:**
```bash
sudo nginx -t  # Config test
sudo systemctl reload nginx
```

**4. SSL Sertifikası (Let's Encrypt):**
```bash
sudo certbot --nginx -d api.yourdomain.com
sudo systemctl reload nginx
```

**5. Auto-renewal test:**
```bash
sudo certbot renew --dry-run
```

### Health Check

```bash
# Local
curl http://localhost:3000/health

# Public (Nginx üzerinden)
curl https://api.yourdomain.com/health
```

Expected response:
```json
{
  "status": "ok",
  "timestamp": "2026-01-04T10:30:00.000Z"
}
```

## 📡 API Endpoints

### Public (Rate Limited)

**POST** `/api/auth/register`
```json
{
  "email": "user@example.com",
  "password": "SecurePass123",
  "name": "John Doe",
  "phone": "+1234567890",
  "country": "USA",
  "deviceInfo": {
    "deviceId": "abc123...",
    "userAgent": "...",
    "screenResolution": "1920x1080",
    "timezone": "America/New_York",
    "language": "en-US",
    "platform": "Win32"
  }
}
```

Response:
```json
{
  "accessToken": "eyJhbGc...",
  "refreshToken": "uuid-v4",
  "expiresIn": 600
}
```

**POST** `/api/auth/login`
```json
{
  "email": "user@example.com",
  "password": "SecurePass123",
  "deviceInfo": { ... }
}
```

**POST** `/api/auth/refresh`
```json
{
  "refreshToken": "uuid-v4",
  "deviceId": "abc123..."
}
```

### Protected (JWT Required)

Header:
```
Authorization: Bearer eyJhbGc...
```

**POST** `/api/auth/logout`
```json
{
  "refreshToken": "uuid-v4"
}
```

**GET** `/api/user/profile`

Response:
```json
{
  "user": {
    "userId": "uid-123",
    "email": "user@example.com",
    "name": "John Doe",
    "phone": "+1234567890",
    "country": "USA"
  }
}
```

**PUT** `/api/user/profile`
```json
{
  "name": "Jane Doe",
  "phone": "+9876543210",
  "country": "Canada"
}
```

**GET** `/api/sessions/active`

Response:
```json
{
  "sessions": [
    {
      "sessionId": "uuid",
      "deviceName": "Win32 - Chrome",
      "ipAddress": "203.0.113.45",
      "lastSeenAt": "2026-01-04T10:30:00Z",
      "isCurrent": true
    }
  ]
}
```

**DELETE** `/api/sessions/:sessionId`

## 📁 Klasör Yapısı

```
server/
├── src/
│   ├── index.js                 # Express app entry
│   ├── config/
│   │   ├── firebase.js          # Firebase Admin init
│   │   ├── jwt.js               # JWT config
│   │   └── constants.js         # Sabitler
│   ├── middleware/
│   │   ├── auth.js              # JWT verification
│   │   ├── rateLimiter.js       # Rate limiting
│   │   ├── replayProtection.js  # Replay attack prevention
│   │   ├── sessionValidator.js  # Session check
│   │   └── errorHandler.js      # Error handling
│   ├── routes/
│   │   ├── auth.routes.js
│   │   ├── user.routes.js
│   │   └── session.routes.js
│   ├── controllers/
│   │   ├── auth.controller.js
│   │   ├── user.controller.js
│   │   └── session.controller.js
│   ├── services/
│   │   ├── auth.service.js
│   │   ├── token.service.js
│   │   ├── session.service.js
│   │   ├── device.service.js
│   │   └── user.service.js
│   └── utils/
│       ├── logger.js
│       ├── crypto.js
│       └── validators.js
├── keys/
│   ├── private.key              # RSA private (600)
│   └── public.key               # RSA public (600)
├── logs/
├── .env                         # Environment vars (600)
├── .env.example
├── serviceAccount.json          # Firebase key (600)
├── package.json
└── ecosystem.config.js          # PM2 config
```

## 🔒 Production Security Checklist

### Network & Firewall

```bash
# UFW (Ubuntu Firewall) setup
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp    # SSH (sadece bastion host'tan izin ver)
sudo ufw allow 80/tcp    # HTTP (Nginx redirect)
sudo ufw allow 443/tcp   # HTTPS
sudo ufw enable

# Firewall status kontrol
sudo ufw status verbose
```

**Expected rules:**
- ✅ Port 22: SSH (key-based auth only)
- ✅ Port 80: HTTP → HTTPS redirect
- ✅ Port 443: HTTPS (Nginx)
- ❌ Port 3000: BLOCKED (sadece localhost)

### SSH Hardening

```bash
# /etc/ssh/sshd_config düzenle
sudo nano /etc/ssh/sshd_config

# Değiştirilmesi gerekenler:
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
ClientAliveInterval 300
ClientAliveCountMax 2

# SSH restart
sudo systemctl restart sshd
```

### Fail2ban Setup

```bash
sudo apt install fail2ban

# Config oluştur
sudo nano /etc/fail2ban/jail.local
```

**jail.local içeriği:**
```ini
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3
destemail = your-email@example.com
sendername = Fail2Ban

[sshd]
enabled = true
port = 22
logpath = /var/log/auth.log

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
logpath = /var/log/nginx/error.log
maxretry = 5

[nginx-noscript]
enabled = true
port = http,https
filter = nginx-noscript
logpath = /var/log/nginx/access.log
```

```bash
sudo systemctl enable fail2ban
sudo systemctl start fail2ban

# Status kontrol
sudo fail2ban-client status
sudo fail2ban-client status sshd
```

### Automatic Security Updates

```bash
sudo apt install unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades

# Auto-update config
sudo nano /etc/apt/apt.conf.d/50unattended-upgrades
# Uncomment: Unattended-Upgrade::Automatic-Reboot "false";
```

### File Permissions Audit

```bash
# Backend directory
ls -la /opt/backend/
# Expected: drwxr-xr-x backenduser backenduser

# Sensitive files (CRITICAL)
ls -la /opt/backend/.env
ls -la /opt/backend/serviceAccount.json
ls -la /opt/backend/keys/
# Expected: -rw------- (600) backenduser backenduser

# Fix permissions if wrong
sudo chmod 600 /opt/backend/.env
sudo chmod 600 /opt/backend/serviceAccount.json
sudo chmod 600 /opt/backend/keys/*
sudo chown -R backenduser:backenduser /opt/backend/
```

### Log Monitoring

```bash
# Backend logs
tail -f /opt/backend/logs/combined.log
tail -f /opt/backend/logs/error.log

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Security events (from logger.js)
grep "SECURITY_EVENT" /opt/backend/logs/combined.log
```

### Redis Security

```bash
# Redis config
sudo nano /etc/redis/redis.conf

# Değiştirilmesi gerekenler:
bind 127.0.0.1  # Sadece localhost
protected-mode yes
requirepass your-strong-password  # .env REDIS_PASSWORD ile aynı

# Restart Redis
sudo systemctl restart redis
```

## 🧪 Test

```bash
npm test
```

## 📊 Performans

- Redis caching ile session lookup hızlı
- JWT verification asenkron
- Firestore batch operations
- Rate limiting Redis-based
- PM2 cluster mode (2+ instances)

## 🤝 Katkıda Bulunma

Production ortamında test edilmeden değişiklik yapmayın!

## 📄 Lisans

MIT

---

**DİKKAT:** Bu sistem "unhackable" DEĞİLDİR. Hiçbir sistem %100 güvenli olamaz. Sürekli monitoring, incident response, ve security audit gereklidir.
